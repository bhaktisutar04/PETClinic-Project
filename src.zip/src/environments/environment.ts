
export const environment = {
  production: false,
  REST_API_URL: 'http://localhost:9090/petclinic/api/'
};
