
export interface Specialty {
  id: number;
  name: string;
}
