
package org.springframework.samples.petclinic.model;

